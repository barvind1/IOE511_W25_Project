function [x_final, f_final, iteration_count, f_history, grad_norm_history] = DFP_with_Wolfe(problem_info, options)
% DFP_with_Wolfe: DFP Quasi-Newton Method with Strong Wolfe Line Search
%
% Inputs:
%   problem_info - Struct containing problem information
%     .func      - Objective function handle
%     .grad      - Gradient function handle
%     .x0        - Initial point
%   options - Optimization settings
%     .alpha     - Initial step size
%     .tau       - Step size reduction factor
%     .c1        - Armijo constant
%     .c2        - Curvature condition constant
%     .max_iter  - Maximum number of iterations
%     .max_ls_iters - Maximum number of line search iterations
%     .tol       - Convergence tolerance
%
% Outputs:
%   x_final           - Final solution
%   f_final           - Final function value
%   iteration_count   - Number of iterations
%   f_history         - History of function values
%   grad_norm_history - History of gradient norms

% Extract initial point and problem data
x = problem_info.x0;
func = problem_info.func;
grad = problem_info.grad;

% Use default options if not provided
if nargin < 2 || isempty(options)
    options = struct();
end
if ~isfield(options, 'alpha')
    options.alpha = 1.0;
end
if ~isfield(options, 'tau')
    options.tau = 0.5;
end
if ~isfield(options, 'c1')
    options.c1 = 1e-4;
end
if ~isfield(options, 'c2')
    options.c2 = 0.9;
end
if ~isfield(options, 'max_iter')
    options.max_iter = 1000;
end
if ~isfield(options, 'max_ls_iters')
    options.max_ls_iters = 20;
end
if ~isfield(options, 'tol')
    options.tol = 1e-6;
end

% Initialization
n = length(x);
B = eye(n);  % Initial Hessian approximation as the identity matrix

% Compute initial function value and gradient
f = func(x);
g = grad(x);
grad_norm = norm(g);

% Initialize history records
max_iter = options.max_iter;
f_history = zeros(max_iter+1, 1);
grad_norm_history = zeros(max_iter+1, 1);

% Record initial values
f_history(1) = f;
grad_norm_history(1) = grad_norm;

% Main iteration loop
iteration_count = 0;
while (iteration_count < max_iter) && (grad_norm > options.tol)
    % Compute search direction
    d = -B * g;
    
    % If not a descent direction, use negative gradient
    if g' * d > 0
        warning('DFP direction is not a descent direction; using negative gradient instead');
        d = -g;
    end
    
    % Strong Wolfe Line Search
    alpha = options.alpha;
    f0 = f;
    dphi0 = g' * d;
    ls_iter = 0;
    
    for k = 1 : options.max_ls_iters
        % Trial point and its function value and gradient
        x_trial = x + alpha * d;
        f_trial = func(x_trial);
        g_trial = grad(x_trial);
        dphi_trial = g_trial' * d;
        
        % Check Armijo condition: sufficient decrease
        armijo = (f_trial <= f0 + options.c1 * alpha * dphi0);
        % Check curvature condition: gradient decrease along direction
        curvature = (abs(dphi_trial) <= -options.c2 * dphi0);
        
        % If both conditions satisfied, accept alpha
        if armijo && curvature
            break;
        end
        
        % Otherwise, reduce step size and continue
        alpha = options.tau * alpha;
        ls_iter = k;
        
        fprintf('Wolfe LS iteration: %d, alpha = %.3e, f_trial = %.3e\n', k, alpha, f_trial);
        
        % If step size is too small, terminate line search
        if alpha < 1e-10
            warning('Step size too small; terminating line search');
            break;
        end
    end
    
    % Update point
    x_new = x + alpha * d;
    
    % Compute new gradient and function value
    g_new = grad(x_new);
    f_new = func(x_new);
    
    % Compute s and y
    s = x_new - x;         % s = x_{k+1} - x_k
    y = g_new - g;         % y = ∇f_{k+1} - ∇f_k
    
    % Update only if curvature condition s'y is sufficiently large
    tol = 1e-10;
    if s' * y > tol
        By = B * y;
        B = B - (By * By') / (y' * By) + (s * s') / (s' * y);
    else
        warning('Skipped DFP update because s''y <= tol');
    end
    
    % Update variables
    x = x_new;
    g = g_new;
    f = f_new;
    grad_norm = norm(g);
    
    % Update iteration count
    iteration_count = iteration_count + 1;
    
    % Record history
    f_history(iteration_count+1) = f;
    grad_norm_history(iteration_count+1) = grad_norm;
    
    % Optional: print progress
    if mod(iteration_count, 10) == 0
        fprintf('Iteration %d: f(x) = %.6e, ||g|| = %.6e\n', iteration_count, f, grad_norm);
    end
end

% Trim history arrays
f_history = f_history(1:iteration_count+1);
grad_norm_history = grad_norm_history(1:iteration_count+1);

% Final results
x_final = x;
f_final = f;

% Print final result
fprintf('DFP with Wolfe completed: Iterations = %d, Function value = %.6e, Gradient norm = %.6e\n', ...
    iteration_count, f_final, grad_norm);

end
