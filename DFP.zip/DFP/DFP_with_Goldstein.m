function [x_final, f_final, iteration_count, f_history, grad_norm_history] = DFP_with_Goldstein(problem_info, options)
% DFP_with_Goldstein: DFP Quasi-Newton Method with Goldstein Line Search
%
% Inputs:
%   problem_info - Struct containing problem information
%     .func      - Objective function handle
%     .grad      - Gradient function handle
%     .x0        - Initial point
%   options - Optimization settings
%     .alpha     - Initial step size
%     .alpha_max - Maximum step size
%     .c1        - Goldstein constant
%     .max_iter  - Maximum number of iterations
%     .max_ls_iters - Maximum number of line search iterations
%     .tol       - Convergence tolerance
%
% Outputs:
%   x_final           - Final solution
%   f_final           - Final function value
%   iteration_count   - Number of iterations
%   f_history         - History of function values
%   grad_norm_history - History of gradient norms

% Extract initial point and problem data
x = problem_info.x0;
func = problem_info.func;
grad = problem_info.grad;

% Use default options if not provided
if nargin < 2 || isempty(options)
    options = struct();
end
if ~isfield(options, 'alpha')
    options.alpha = 1.0;
end
if ~isfield(options, 'alpha_max')
    options.alpha_max = 1000.0;
end
if ~isfield(options, 'c1')
    options.c1 = 0.1;
end
if ~isfield(options, 'max_iter')
    options.max_iter = 1000;
end
if ~isfield(options, 'max_ls_iters')
    options.max_ls_iters = 50;
end
if ~isfield(options, 'tol')
    options.tol = 1e-6;
end

% Initialization
n = length(x);
B = eye(n);  % Initial Hessian approximation as the identity matrix

% Compute initial function value and gradient
f = func(x);
g = grad(x);
grad_norm = norm(g);

% Initialize history recording
max_iter = options.max_iter;
f_history = zeros(max_iter+1, 1);
grad_norm_history = zeros(max_iter+1, 1);

% Record initial values
f_history(1) = f;
grad_norm_history(1) = grad_norm;

% Main iteration loop
iteration_count = 0;
while (iteration_count < max_iter) && (grad_norm > options.tol)
    % Compute search direction
    d = -B * g;
    
    % Ensure it is a descent direction
    if g' * d > 0
        warning('DFP direction is not a descent direction; using negative gradient instead');
        d = -g;
    end
    
    % Goldstein Line Search
    alpha = options.alpha;
    f0 = f;
    dphi0 = g' * d;
    lo = 0;
    hi = options.alpha_max;
    ls_iter = 0;
    tol = 1e-12;
    
    for k = 1 : options.max_ls_iters
        x_trial = x + alpha * d;
        phi = func(x_trial);
        
        % Compute Goldstein bounds
        upper = f0 + options.c1 * alpha * dphi0;             % Armijo upper bound
        lower = f0 + (1 - options.c1) * alpha * dphi0;       % Goldstein lower bound
        
        if phi > upper
            % Insufficient decrease: step size too large
            hi = alpha;
        elseif phi < lower
            % Overshooting: step size too small
            lo = alpha;
        else
            % Within [lower, upper]: accept alpha
            break;
        end
        
        % Bisection method within the interval
        alpha = 0.5 * (lo + hi);
        ls_iter = k;
    end
    
    % Update point
    x_new = x + alpha * d;
    
    % Compute new gradient and function value
    g_new = grad(x_new);
    f_new = func(x_new);
    
    % Compute s and y
    s = x_new - x;      % s = x_{k+1} - x_k
    y = g_new - g;      % y = ∇f_{k+1} - ∇f_k
    
    % Only update if s'y is sufficiently large
    if s' * y > tol
        By = B * y;
        B = B - (By * By') / (y' * By) + (s * s') / (s' * y);
    else
        warning('Skipped DFP update due to small s''y');
    end
    
    % Update variables
    x = x_new;
    g = g_new;
    f = f_new;
    grad_norm = norm(g);
    
    % Update iteration count
    iteration_count = iteration_count + 1;
    
    % Record history
    f_history(iteration_count+1) = f;
    grad_norm_history(iteration_count+1) = grad_norm;
    
    % Optional: print progress
    if mod(iteration_count, 10) == 0
        fprintf('Iteration %d: f(x) = %.6e, ||g|| = %.6e\n', iteration_count, f, grad_norm);
    end
end

% Trim history arrays
f_history = f_history(1:iteration_count+1);
grad_norm_history = grad_norm_history(1:iteration_count+1);

% Final result
x_final = x;
f_final = f;

% Print final result
fprintf('DFP with Goldstein completed: Iterations = %d, Function value = %.6e, Gradient norm = %.6e\n', ...
    iteration_count, f_final, grad_norm);

end
