function g = counting_grad(x, original_grad)
    global GRAD_COUNT;
    GRAD_COUNT = GRAD_COUNT + 1;
    g = original_grad(x);
end
