function [method, method_name] = Setmethods(method_id)
    % SETMETHODS  select optimization routine
    switch method_id
        case 1
            method = @Newton_backtracking;
            method_name = 'Newton with Backtracking';
        case 2
            method = @NewtonW_wolfe;
            method_name = 'Newton with Wolfe';
        case 3
            method = @DFP_backtracking;
            method_name = 'DFP with Backtracking';
        case 4
            method = @DFP_with_Wolfe;
            method_name = 'DFP with Wolfe';
        case 5
            method = @DFP_with_Goldstein;
            method_name = 'DFP with Goldstein';
        case 6
            method = @Modified_Newton_with_Wolfe;
            method_name = 'Modified Newton with Wolfe';
        case 7
            method = @Modified_Newton_with_Goldstein;
            method_name = 'Modified Newton with Goldstein';
        otherwise
            error('Unknown method ID: %d', method_id);
    end
end
