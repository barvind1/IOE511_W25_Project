function H = counting_hess(x, original_hess)
    % Wrapper function to count Hessian evaluations
    global HESS_COUNT;
    HESS_COUNT = HESS_COUNT + 1;
    H = original_hess(x);
end
