function plot_convergence(results, algorithm_names)
    % Plot convergence history
    problem_ids = fieldnames(results);
    
    % Select some representative problems for plotting
    selected_problems = {'P1_quad_10_10', 'P2_quad_10_1000',...
        'P3_quad_1000_10','P4_quad_1000_1000','P5_quartic_1',...
        'P6_quartic_2', 'P7_Rosenbrock_2', 'P8_Rosenbrock_100',...
        'P9_DataFit_2','P10_Exponential_10','P11_Exponential_100','P12_Genhumps_5'};
    
    for i = 1:length(selected_problems)
        if ~ismember(selected_problems{i}, problem_ids)
            continue;
        end
        
        problem_id = selected_problems{i};
        problem_results = results.(problem_id);
        
        % Create figure
        figure;
        
        % Function value history
        subplot(1, 2, 1);
        hold on;
        title(['Function Value History - ', strrep(problem_id, '_', ' ')]);
        xlabel('Iteration');
        ylabel('f(x)');
        
        % Gradient norm history
        subplot(1, 2, 2);
        hold on;
        title(['Gradient Norm History - ', strrep(problem_id, '_', ' ')]);
        xlabel('Iteration');
        ylabel('||∇f(x)||');
        set(gca, 'YScale', 'log');
        
        line_styles = {'-', '--', ':', '-.', '-o', '-x'};
        colors = {'b', 'r', 'g', 'm', 'c', 'k'};
        % Plot convergence history for each algorithm
        for alg_idx = 1:length(algorithm_names)
            alg_name = algorithm_names{alg_idx};
            alg_key = strrep(alg_name, ' ', '_');
            style_idx = mod(alg_idx-1, length(line_styles))+1;
            color_idx = mod(alg_idx-1, length(colors))+1;
            
            if isfield(problem_results, alg_key)
                result = problem_results.(alg_key);
                
                % Function value history
                subplot(1, 2, 1);
                plot(0:length(result.f_history)-1, result.f_history, line_styles{style_idx}, 'Color', colors{color_idx}, 'LineWidth', 2, 'DisplayName', alg_name);
                
                % Gradient norm history
                subplot(1, 2, 2);
                semilogy(0:length(result.grad_norm_history)-1, result.grad_norm_history, line_styles{style_idx}, 'Color', colors{color_idx}, 'LineWidth', 2, 'DisplayName', alg_name);
            end
        end
        
        % Add legend
        subplot(1, 2, 1);
        legend('Location', 'best');
        grid on;
        
        subplot(1, 2, 2);
        legend('Location', 'best');
        grid on;
        
        % Removed image saving code
        % saveas(gcf, [problem_id, '_convergence.png']);
    end
end
