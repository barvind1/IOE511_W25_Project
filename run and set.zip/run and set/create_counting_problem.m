function wrapped_problem = create_counting_problem(problem_info)
    
    wrapped_problem = problem_info;
    % original functions
    original_func = problem_info.func;
    original_grad = problem_info.grad;
    original_hess = problem_info.hess;

    wrapped_problem.func = @(x) counting_func(x, original_func);
    
    if problem_info.has_grad
        wrapped_problem.grad = @(x) counting_grad(x, original_grad);
    end
    
    if problem_info.has_hess
        wrapped_problem.hess = @(x) counting_hess(x, original_hess);
    end
end

