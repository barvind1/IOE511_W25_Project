function create_detailed_tables(results, algorithm_names)
    % Create detailed tables for each algorithm
    problem_ids = fieldnames(results);
    
    for alg_idx = 1:length(algorithm_names)
        alg_name = algorithm_names{alg_idx};
        alg_key = strrep(alg_name, ' ', '_');
        
        fprintf('\n\\begin{table}[htbp]\n');
        fprintf('\\centering\n');
        fprintf('\\caption{Performance of %s}\n', alg_name);
        fprintf('\\begin{tabular}{lrrrr}\n');
        fprintf('\\hline\n');
        fprintf('Problem & Iterations & Function Evals & Gradient Evals & CPU Time(s) \\\\\n');
        fprintf('\\hline\n');
        
        for i = 1:length(problem_ids)
            problem_id = problem_ids{i};
            problem_results = results.(problem_id);
            
            if isfield(problem_results, alg_key)
                result = problem_results.(alg_key);
                fprintf('%s & %d & %d & %d & %.4f \\\\\n', ...
                    strrep(problem_id, '_', ' '), ...
                    result.iterations, ...
                    result.func_evals, ...
                    result.grad_evals, ...
                    result.runtime);
            else
                fprintf('%s & -- & -- & -- & -- \\\\\n', strrep(problem_id, '_', ' '));
            end
        end
        
        fprintf('\\hline\n');
        fprintf('\\end{tabular}\n');
        fprintf('\\end{table}\n');
    end
end
