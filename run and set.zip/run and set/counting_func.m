function f = counting_func(x, original_func)
    global FUNC_COUNT;
    FUNC_COUNT = FUNC_COUNT + 1;
    f = original_func(x);
end

