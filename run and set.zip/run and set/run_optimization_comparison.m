function results = run_optimization_comparison()
    % Compare the performance of all optimization algorithms
    
    % Define the algorithms to be tested
    algorithms = {
        @DFP_with_backtracking_LS, ...
        @DFP_with_Goldstein, ...
        @DFP_with_Wolfe, ...
        @Modified_Newton_with_Goldstein, ...
        @Modified_Newton_with_LS, ...
        @Modified_Newton_with_Wolfe
    };
    
    algorithm_names = {
        'DFP with Backtracking LS', ...
        'DFP with Goldstein', ...
        'DFP with Wolfe', ...
        'Modified Newton with Goldstein', ...
        'Modified Newton with LS',...
        'Modified Newton with Wolfe'
    };
    
    % Initialize results structure
    results = struct();
    
    % Print table header (Markdown format)
    fprintf('\n## Performance Comparison of Optimization Algorithms\n\n');
    fprintf('| Problem | Iterations | Function Evals | Gradient Evals | CPU Time(s) |\n');
    fprintf('|---------|------------|---------------|---------------|------------|\n');
    
    % Loop through all problems
    for problem_id = 1:12
        % Get problem information
        problem_info = Setproblems(problem_id);
        problem_name = problem_info.name;
        
        % Create result storage for current problem
        results.(problem_info.id) = struct();
        
        % Track the best result among all algorithms
        best_iter = inf;
        best_func_evals = inf;
        best_grad_evals = inf;
        best_time = inf;
        best_alg = '';
        
        if problem_id == 1
            fprintf('\n### Results for Each Algorithm\n\n');
            fprintf('| Problem | Algorithm | Iterations | Function Evals | Gradient Evals | CPU Time(s) |\n');
            fprintf('|---------|-----------|------------|---------------|---------------|------------|\n');
        end 

        % Test each algorithm
        for alg_idx = 1:length(algorithms)
            algorithm = algorithms{alg_idx};
            alg_name = strrep(algorithm_names{alg_idx}, ' ', '_');
            
            % Create a wrapped problem structure with counters
            wrapped_problem = create_counting_problem(problem_info);
            
            % Reset global counters
            global FUNC_COUNT GRAD_COUNT HESS_COUNT;
            FUNC_COUNT = 0;
            GRAD_COUNT = 0;
            HESS_COUNT = 0;
            
            % Set options
            options = Setoptions(alg_idx);
            
            try
                % Run algorithm and time it
                tic;
                [x_final, f_final, iteration_count, f_history, grad_norm_history] = algorithm(wrapped_problem, options);
                runtime = toc;
                
                % Store results
                results.(problem_info.id).(alg_name) = struct(...
                    'x_final', x_final, ...
                    'f_final', f_final, ...
                    'iterations', iteration_count, ...
                    'func_evals', FUNC_COUNT, ...
                    'grad_evals', GRAD_COUNT, ...
                    'hess_evals', HESS_COUNT, ...
                    'runtime', runtime, ...
                    'f_history', f_history, ...
                    'grad_norm_history', grad_norm_history ...
                );
                
                % Update best result
                if iteration_count < best_iter
                    best_iter = iteration_count;
                    best_func_evals = FUNC_COUNT;
                    best_grad_evals = GRAD_COUNT;
                    best_time = runtime;
                    best_alg = alg_name;
                end
                
                % Optional: print result for each algorithm
                 fprintf('| %s | %s | %d | %d | %d | %.4f |\n', ...
                    problem_name, algorithm_names{alg_idx}, iteration_count, FUNC_COUNT, GRAD_COUNT, runtime);
            catch ME
                warning('Algorithm %s failed on problem %s: %s', algorithm_names{alg_idx}, problem_name, ME.message);
                fprintf('| %s | %s | Failed | Failed | Failed | Failed |\n', ...
                    problem_name, algorithm_names{alg_idx});
            end
        end
        
        % Print best result
        if problem_id == 1
            fprintf('\n### Best Results For Each Problem\n\n');
            fprintf('| Problem | Iterations | Function Evals | Gradient Evals | CPU Time(s) | Best Algorithm |\n');
            fprintf('|---------|------------|---------------|---------------|------------|---------------|\n');
        end
        
        fprintf('| %s | %d | %d | %d | %.4f | %s |\n', ...
            problem_name, best_iter, best_func_evals, best_grad_evals, best_time, best_alg);
    end

    % Save results
    save('optimization_results.mat', 'results');
    fprintf('Results saved to optimization_results.mat\n');

    
    % Create more detailed result tables
    create_detailed_tables(results, algorithm_names);
    
    % Plot convergence graphs
    plot_convergence(results, algorithm_names);
end
