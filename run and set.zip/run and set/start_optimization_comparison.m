clear;
close all;

restoredefaultpath;
addpath(genpath(pwd));
addpath('problems');

% Define algorithm names
algorithm_names = {
   'DFP with Backtracking LS', ...
    'DFP with Goldstein', ...
    'DFP with Wolfe', ...
    'Modified Newton with Goldstein', ...
    'Modified Newton with LS', ...
    'Modified Newton with Wolfe'
};

% Run optimization comparison
fprintf('Starting optimization algorithm comparison...\n');
results = run_optimization_comparison();

fprintf('Done!\n');
