function options = Setoptions(method_id)
    % SETOPTIONS Set optimization options
    %
    % Input:
    %   method_id - Algorithm ID (1-6)
    %
    % Output:
    %   options - Struct containing algorithm options
    
    % Common options
    options = struct();
    options.max_iter = 1000;
    options.tol = 1e-6;
    
    switch method_id
        case 1  % DFP + Backtracking Line Search
            options.alpha = 1.0;
            options.tau = 0.5;
            options.c1 = 1e-4;
            
        case 2  % DFP + Goldstein Line Search
            options.alpha = 1.0;
            options.alpha_max = 1000.0;
            options.c1 = 0.1;
            options.max_ls_iters = 50;
            
        case 3  % DFP + Wolfe Line Search
            options.alpha = 1.0;
            options.c1 = 1e-4;
            options.c2 = 0.9;
            options.tau = 0.5;
            options.max_ls_iters = 20;
            
        case 4  % Modified Newton + Goldstein Line Search
            options.alpha = 1.0;
            options.alpha_max = 1000.0;
            options.c1 = 0.1;
            options.beta = 1e-6;
            options.max_ls_iters = 50;
            
        case 5  % Modified Newton + Backtracking Line Search
            options.alpha = 1.0;
            options.tau = 0.5;
            options.c1 = 1e-4;
            options.beta = 1e-6;
            
        case 6  % Modified Newton + Wolfe Line Search
            options.alpha = 1.0;
            options.c1 = 1e-4;
            options.c2 = 0.9;
            options.tau = 0.5;
            options.beta = 1e-6;
            options.max_ls_iters = 20;
            
        otherwise
            error('Unknown algorithm ID: %d', method_id);
    end
end
