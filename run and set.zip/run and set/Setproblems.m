function [problem_info] = Setproblems(problem_id)
  % SETPROBLEMS Sets up optimization problems
  %
  % Input:
  %   problem_id - Problem ID (1-12)
  %
  % Output:
  %   problem_info - A structure containing problem information
  %     .id        - Problem identifier
  %     .name      - Problem name
  %     .func      - Objective function handle (if provided)
  %     .grad      - Gradient function handle (if provided)
  %     .hess      - Hessian function handle (if provided)
  %     .x0        - Initial point
  %     .dimension - Problem dimension
  %     .has_func  - Whether the objective function is provided
  %     .has_grad  - Whether the gradient function is provided
  %     .has_hess  - Whether the Hessian function is provided

    problem_info = struct();
    
    switch problem_id
        case 1
            % P1: Quadratic function, n=10, κ=10
            problem_info.id = 'P1_quad_10_10';
            problem_info.name = 'Quadratic Function n=10, κ=10';
            problem_info.dimension = 10;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;

            % Set random seed for reproducibility
            rng(0);
            problem_info.x0 = 20*rand(10, 1) - 10;

            problem_info.func = str2func('quad_10_10_func');
            problem_info.grad = str2func('quad_10_10_grad');
            problem_info.hess = str2func('quad_10_10_Hess');

        case 2
            % P2: Quadratic function, n=10, κ=1000
            problem_info.id = 'P2_quad_10_1000';
            problem_info.name = 'Quadratic Function n=10, κ=1000';
            problem_info.dimension = 10;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;

            rng(0);
            problem_info.x0 = 20*rand(10, 1) - 10;
            problem_info.func = str2func('quad_10_1000_func');
            problem_info.grad = str2func('quad_10_1000_grad');
            problem_info.hess = str2func('quad_10_1000_Hess');

        case 3
            % P3: Quadratic function, n=1000, κ=10
            problem_info.id = 'P3_quad_1000_10';
            problem_info.name = 'Quadratic Function n=1000, κ=10';
            problem_info.dimension = 1000;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;

            rng(0);
            problem_info.x0 = 20*rand(1000, 1) - 10;
            problem_info.func = str2func('quad_1000_10_func');
            problem_info.grad = str2func('quad_1000_10_grad');
            problem_info.hess = str2func('quad_1000_10_Hess');

        case 4
            % P4: Quadratic function, n=1000, κ=1000
            problem_info.id = 'P4_quad_1000_1000';
            problem_info.name = 'Quadratic Function n=1000, κ=1000';
            problem_info.dimension = 1000;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;

            rng(0);
            problem_info.x0 = 20*rand(1000, 1) - 10;
            problem_info.func = str2func('quad_1000_1000_func');
            problem_info.grad = str2func('quad_1000_1000_grad');
            problem_info.hess = str2func('quad_1000_1000_Hess');

        case 5
            % P5: Quartic function with σ=10^-4
            problem_info.id = 'P5_quartic_1';
            problem_info.name = 'Quartic Function with σ=10^-4';
            problem_info.dimension = 4;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;

            problem_info.x0 = [cos(70); sin(70); cos(70); sin(70)];
            problem_info.func = str2func('quartic_1_func');
            problem_info.grad = str2func('quartic_1_grad');
            problem_info.hess = str2func('quartic_1_Hess');

        case 6
            % P6: Quartic function with σ=10^4
            problem_info.id = 'P6_quartic_2';
            problem_info.name = 'Quartic Function with σ=10^4';
            problem_info.dimension = 4;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;

            problem_info.x0 = [cos(70); sin(70); cos(70); sin(70)];
            problem_info.func = str2func('quartic_2_func');
            problem_info.grad = str2func('quartic_2_grad');
            problem_info.hess = str2func('quartic_2_Hess');

        case 7
            % P7: 2D Rosenbrock function
            problem_info.id = 'P7_Rosenbrock_2';
            problem_info.name = 'Rosenbrock Function n=2';
            problem_info.dimension = 2;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;

            problem_info.x0 = [-1.2; 1.0];
            problem_info.func = str2func('Rosenbrock_2_func');
            problem_info.grad = str2func('Rosenbrock_2_grad');
            problem_info.hess = str2func('Rosenbrock_2_Hess');

        case 8
            % P8: 100D Rosenbrock function
            problem_info.id = 'P8_Rosenbrock_100';
            problem_info.name = 'Rosenbrock Function n=100';
            problem_info.dimension = 100;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = false; % Hessian is not provided

            x0 = ones(100, 1);
            x0(1) = -1.2;
            problem_info.x0 = x0;
            problem_info.func = str2func('rosenbrock_100_func');
            problem_info.grad = str2func('rosenbrock_100_grad');
            problem_info.hess = str2func('rosenbrock_100_Hess');

        case 9
            % P9: Data fitting problem, n=2
            problem_info.id = 'P9_DataFit_2';
            problem_info.name = 'Data Fitting Function n=2';
            problem_info.dimension = 2;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;

            problem_info.x0 = [1; 1];
            problem_info.func = str2func('DataFit_2_func');
            problem_info.grad = str2func('DataFit_2_grad');
            problem_info.hess = str2func('DataFit_2_Hess');

        case 10
            % P10: Exponential function, n=10
            problem_info.id = 'P10_Exponential_10';
            problem_info.name = 'Exponential Function n=10';
            problem_info.dimension = 10;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;

            problem_info.x0 = [1; zeros(9, 1)];
            problem_info.func = str2func('Exponential_10_func');
            problem_info.grad = str2func('Exponential_10_grad');
            problem_info.hess = str2func('Exponential_10_Hess');

        case 11
            % P11: Exponential function, n=100
            problem_info.id = 'P11_Exponential_100';
            problem_info.name = 'Exponential Function n=100';
            problem_info.dimension = 100;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;

            problem_info.x0 = [1; zeros(99, 1)];
            problem_info.func = str2func('Exponential_100_func');
            problem_info.grad = str2func('Exponential_100_grad');
            problem_info.hess = str2func('Exponential_100_Hess');

        case 12
            % P12: Generalized humps function, n=5
            problem_info.id = 'P12_Genhumps_5';
            problem_info.name = 'Generalized Humps Function n=5';
            problem_info.dimension = 5;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;

            problem_info.x0 = [-506.2; 506.2; 506.2; 506.2; 506.2];
            problem_info.func = str2func('genhumps_5_func');
            problem_info.grad = str2func('genhumps_5_grad');
            problem_info.hess = str2func('genhumps_5_Hess');

        otherwise
            error('Unknown problem ID: %d', problem_id);
    end
end
