function [method] = setMethod(method)
    if ~isfield(method, 'name')
        error('Method not specified!');
    end

    switch method.name
        case 'GradientDescent'
            if ~isfield(method, 'step_type')
                error('Step type not specified!');
            end

            if strcmp(method.step_type, 'GradientDescent')
                method.alpha_bar = 1;
                method.c1 = 1e-4;
                method.tau = 0.5;

            elseif strcmp(method.step_type, 'GradientDescentW')
                method.alpha = 1;
                method.alpha_low = 0;
                method.alpha_high = 1000;
                method.c1 = 1e-4;
                method.c2 = 0.9;
                method.c = 0.5;

            elseif strcmp(method.step_type, 'GradientDescentG')
                method.alpha = 1;
                method.alpha_low = 0;
                method.alpha_high = 1000;
                method.c = 0.1;
                method.bisect_c = 0.5;
                method.max_goldstein_iters = 50;

            elseif strcmp(method.step_type, 'Constant')
                method.constant_step_size = 1e-2;

            else
                error('Invalid step_type.');
            end

        case 'TRNewtonCG'
            method.delta0 = 0.1;
            method.eta = 0.1;
            method.delta_max = 1000;
            method.step_type = 'TRNewtonCG';

        case 'TR1CG'
            method.delta0 = 1;
            method.eta = 0.1;
            method.delta_max = 1000;
            method.step_type = 'TR1CG';

        otherwise
            error('Unknown method!');
    end
end
