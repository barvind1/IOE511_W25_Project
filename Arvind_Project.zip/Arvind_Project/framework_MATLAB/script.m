clear; clc;
options = setOptions();
addpath(genpath('/MATLAB Drive/Arvind_Project/framework_MATLAB/Project_Problems_MATLAB'));

problem_list = {
    'quad_10_10','quad_10_1000','quad_1000_10','quad_1000_1000', ...
    'quartic_1','quartic_2','genhumps_5', ...
    'Rosenbrock_2','Rosenbrock_100', ...
    'Datafit_2','Exponential_10','Exponential_1000'
};

for i = 1:length(problem_list)
    pname = problem_list{i};
    fprintf('\nRunning: %s\n', pname);

    %% -------- GradientDescent (Backtracking) --------
    try
        problem = setProblem(struct('name', pname));
        method.name = 'GradientDescent';
        method.step_type = 'GradientDescent';
        method = setMethod(method);

        [x, f, f_values] = optSolver_Balaji_Arvind(problem, method, options);
        figure;
        semilogy(1:length(f_values), f_values, '-o', 'LineWidth', 2);
        xlabel('Iteration'); ylabel('f(x_k)');
        title(sprintf('%s - GD Backtracking', strrep(pname, '_', '\_')));
        grid on;
    catch ME
        warning('Error in %s (Backtracking): %s\n', pname, ME.message);
    end

    %% -------- GradientDescentW (Wolfe) --------
    try
        problem = setProblem(struct('name', pname));
        method.name = 'GradientDescent';
        method.step_type = 'GradientDescentW';
        method = setMethod(method);

        [x, f, f_values] = optSolver_Balaji_Arvind(problem, method, options);
        figure;
        semilogy(1:length(f_values), f_values, '-o', 'LineWidth', 2);
        xlabel('Iteration'); ylabel('f(x_k)');
        title(sprintf('%s - GD Wolfe', strrep(pname, '_', '\_')));
        grid on;
    catch ME
        warning('Error in %s (Wolfe): %s\n', pname, ME.message);
    end


%% -------- GradientDescentW (Goldstein) --------
    try
        problem = setProblem(struct('name', pname));
        method.name = 'GradientDescent';
        method.step_type = 'GradientDescentG';
        method = setMethod(method);

        [x, f, f_values] = optSolver_Balaji_Arvind(problem, method, options);
        figure;
        semilogy(1:length(f_values), f_values, '-o', 'LineWidth', 2);
        xlabel('Iteration'); ylabel('f(x_k)');
        title(sprintf('%s - GD Goldstein', strrep(pname, '_', '\_')));
        grid on;
    catch ME
        warning('Error in %s (Goldstein): %s\n', pname, ME.message);
    end





    %% -------- TRNewtonCG --------
    try
        problem = setProblem(struct('name', pname));
        method.name = 'TRNewtonCG';
        method = setMethod(method);

        [x, f, f_values] = optSolver_Balaji_Arvind(problem, method, options);
        figure;
        semilogy(1:length(f_values), f_values, '-o', 'LineWidth', 2);
        xlabel('Iteration'); ylabel('f(x_k)');
        title(sprintf('%s - TRNewtonCG', strrep(pname, '_', '\_')));
        grid on;
    catch ME
        warning('Error in %s (TRNewtonCG): %s\n', pname, ME.message);
    end

    %% -------- TR1CG --------
    try
        problem = setProblem(struct('name', pname));
        method.name = 'TR1CG';
        method = setMethod(method);

        [x, f, f_values] = optSolver_Balaji_Arvind(problem, method, options);
        figure;
        semilogy(1:length(f_values), f_values, '-o', 'LineWidth', 2);
        xlabel('Iteration'); ylabel('f(x_k)');
        title(sprintf('%s - TR1CG SR1', strrep(pname, '_', '\_')));
        grid on;
    catch ME
        warning('Error in %s (TR1CG): %s\n', pname, ME.message);
    end
end
