function [x_new, f_new, g_new, success, alpha] = GDStep(x, problem, method, d)
    if nargin < 4
        d = -problem.compute_g(x);
    end

    g = problem.compute_g(x);
    f = problem.compute_f(x);

   % ---- Weak Wolfe Line Search ----
    if strcmp(method.step_type, 'GradientDescentW')
    c1 = method.c1;
    c2 = method.c2;
    alpha = method.alpha;
    alpha_low = method.alpha_low;
    alpha_high = method.alpha_high;
    c = method.c;
    

    while true
        x_trial = x + alpha * d;
        f_trial = problem.compute_f(x_trial);
        
        % Check Armijo condition (3) first
        if f_trial <= f + c1 * alpha * g'* d
            % Armijo holds - now check curvature (4)
            g_trial = problem.compute_g(x_trial);
            if g_trial' * d >= c2 * g'* d
                break;  % Both conditions satisfied
            end
            % Only update alpha_low if Armijo holds but curvature fails
            alpha_low = alpha;
        else
            % Armijo fails - update alpha_high
            alpha_high = alpha;
        end
        
        % Update alpha via interpolation
        alpha = c * alpha_low + (1 - c) * alpha_high;
        
       
    end
    success = true;



    % ---- Goldstein Line Search ------------------------------------
elseif strcmp(method.step_type, 'GradientDescentG')
    c = method.c;
    alpha = method.alpha;
    alpha_low = method.alpha_low;
    alpha_high = method.alpha_high;
    bisect_c = method.bisect_c;

    gtd = g' * d;
    if gtd >= 0
        error('[Goldstein] Not a descent direction: g^T d = %.4e', gtd);
    end

    while true
        x_trial = x + alpha * d;
        f_trial = problem.compute_f(x_trial);

        ub = f + c * alpha * gtd;
        lb = f + (1 - c) * alpha * gtd;
        %fprintf('[Goldstein] alpha = %.5f | f_trial = %.8f | lower = %.8f | upper = %.8f\n', ...
                %alpha, f_trial, lb, ub);

        if f_trial < lb
            alpha_low = alpha;
        elseif f_trial > ub
            alpha_high = alpha;
        else
            break;  % Condition satisfied
        end

        alpha = bisect_c * alpha_low + (1 - bisect_c) * alpha_high;
    end

    success = true;









  

    % ---- Backtracking Line Search ----
    elseif strcmp(method.step_type, 'GradientDescent')
        alpha = method.alpha_bar;
        while problem.compute_f(x + alpha * d) > f + method.c1 * alpha * g' * d
            alpha = method.tau * alpha;
        end
        success = true;

    % ---- Constant Step ----
    elseif strcmp(method.step_type, 'Constant')
        alpha = method.constant_step_size;
        success = true;

    else
        error('Invalid step_type.');
    end

    x_new = x + alpha * d;
    f_new = problem.compute_f(x_new);
    g_new = problem.compute_g(x_new);
end
