function H = quartic_1_Hess(x)
% IOE 511/MATH 562, University of Michigan
% Problem Number: 5
% Problem Name: quartic_1

Q = [5 1 0 0.5;
     1 4 0.5 0;
     0 0.5 3 0;
     0.5 0 0 2];

sigma = 1e-4;

qx = Q * x;
H = eye(4) + sigma * (qx * qx' + (x' * qx) * Q);
end
