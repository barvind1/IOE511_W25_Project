function g = Rosenbrock_100_grad(x)
% Gradient of Rosenbrock function for n = 100
n = length(x);
g = zeros(n,1);

for i = 1:n-1
    g(i) = g(i) - 2*(1 - x(i)) - 400*x(i)*(x(i+1) - x(i)^2);
    g(i+1) = g(i+1) + 200*(x(i+1) - x(i)^2);
end
end
