function f = Rosenbrock_100_func(x)
% Rosenbrock function for n = 100
f = sum((1 - x(1:end-1)).^2 + 100 * (x(2:end) - x(1:end-1).^2).^2);
end
