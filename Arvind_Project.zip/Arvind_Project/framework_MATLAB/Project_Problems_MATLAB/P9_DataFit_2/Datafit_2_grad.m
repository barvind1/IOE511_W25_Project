function g = Datafit_2_grad(x)
% Gradient of DataFit_2

y = [1.5; 2.25; 2.625];
powers = (1:3)';
phi = 1 - x(2).^powers;

g = [
    -2 * sum((y - x(1) * phi) .* phi);
     2 * x(1) * sum((y - x(1) * phi) .* powers .* x(2).^(powers - 1))
];
end
