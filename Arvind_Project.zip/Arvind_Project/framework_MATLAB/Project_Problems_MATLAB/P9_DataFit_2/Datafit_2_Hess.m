function H = Datafit_2_Hess(x)
% Hessian of DataFit_2

y = [1.5; 2.25; 2.625];
powers = (1:3)';
phi = 1 - x(2).^powers;
phi_prime = powers .* x(2).^(powers - 1);
phi_double_prime = powers .* (powers - 1) .* x(2).^(powers - 2);

residual = y - x(1) * phi;

H = [
    2 * sum(phi.^2), ...
    -2 * sum(phi .* phi_prime) - 2 * x(1) * sum(phi .* phi_prime);

    -2 * sum(phi .* phi_prime) - 2 * x(1) * sum(phi .* phi_prime), ...
    2 * x(1)^2 * sum(phi_prime.^2) + 2 * x(1) * sum(residual .* phi_double_prime)
];
end
