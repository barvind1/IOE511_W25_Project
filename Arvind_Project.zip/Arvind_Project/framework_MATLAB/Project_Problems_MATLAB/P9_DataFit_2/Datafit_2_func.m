function f = Datafit_2_func(x)
% Problem 9 - DataFit_2
y = [1.5; 2.25; 2.625];
powers = (1:3)';
phi = 1 - x(2).^powers;

f = sum((y - x(1) * phi).^2);
end
