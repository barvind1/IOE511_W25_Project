function [x_new, f_new, g_new, delta, B_new] = TR1CGStep(x, f, g, B, problem, delta, options)
    % Trust Region SR1 with CG solver (TR1CG)
    
    % Solve the trust region subproblem using CG Steihaug
    d = TR1CG_solveTRSubproblem(g, B, delta, options.term_tol_CG, options.max_iterations_CG);

    % Evaluate trial point
    x_trial = x + d;
    f_trial = problem.compute_f(x_trial);
    g_trial = problem.compute_g(x_trial);

    % Actual and predicted reduction
    actual_red = f - f_trial;
    predicted_red = -g' * d - 0.5 * d' * B * d;
    rho = actual_red / predicted_red;

    if ~isfinite(rho) || predicted_red <= 0
    fprintf('[WARN] rho is invalid: actual=%.3e, predicted=%.3e → rho=%.3e\n', ...
        actual_red, predicted_red, rho);
    end



    %fprintf('[TR1CG] f=%.3e | actual=%.3e | predicted=%.3e | rho=%.2f | delta=%.2e\n', ...
    %f, actual_red, predicted_red, rho, delta);




    % Trust region update logic
    c1 = options.c1_tr;
    c2 = options.c2_tr;
    if rho > c1
        x_new = x_trial;
        f_new = f_trial;
        g_new = g_trial;
        if rho > c2
            delta = min(2 * delta, options.delta_max);
        end
    else
        x_new = x;
        f_new = f;
        g_new = g;
        delta = 0.5 * delta;
    end

    % SR1 Update
    s = x_new - x;
    y = g_new - g;
    Bs = B * s;
    diff = y - Bs;
    denom = diff' * s;

    if abs(denom) >= 1e-8 * norm(diff) * norm(s) && denom > 0
        B_new = B + (diff * diff') / denom;
    else
        %Log skipped SR1 updates
        %fprintf('[SR1 SKIP] | ‖s‖=%.2e | ‖y - Bs‖=%.2e | denom=%.2e\n', ...
            %norm(s), norm(diff), denom);
        B_new = B;
    end
end

function d = TR1CG_solveTRSubproblem(g, B, delta, tol_CG, max_iter_CG)
    % CG Steihaug for SR1 TR solver (duplicated version for TR1CG)
    z = zeros(size(g));
    r = g;
    p = -r;

    if norm(r) < tol_CG
        d = z;
        return;
    end

    for j = 1:max_iter_CG
        Bp = B * p;
        pBp = p' * Bp;

        if pBp <= 0
            tau = TR1CG_findTau(z, p, delta);
            d = z + tau * p;
            return;
        end

        alpha_j = (r' * r) / pBp;
        z_new = z + alpha_j * p;

        if norm(z_new) >= delta
            tau = TR1CG_findTau(z, p, delta);
            d = z + tau * p;
            return;
        end

        r_new = r + alpha_j * Bp;

        if norm(r_new) <= tol_CG
            d = z_new;
            return;
        end

        beta = (r_new' * r_new) / (r' * r);
        p = -r_new + beta * p;
        r = r_new;
        z = z_new;
    end

    d = z;
end

function tau = TR1CG_findTau(z, p, delta)
    % Find tau such that ||z + tau*p|| = delta
    a = norm(p)^2;
    b = 2 * z' * p;
    c = norm(z)^2 - delta^2;
    discriminant = b^2 - 4 * a * c;
    tau = (-b + sqrt(discriminant)) / (2 * a);  % larger root
end
