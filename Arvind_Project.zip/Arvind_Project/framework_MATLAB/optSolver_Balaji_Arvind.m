function [x, f, f_values] = optSolver_Balaji_Arvind(problem, method, options)
    x = problem.x0;
    f = problem.compute_f(x);
    g = problem.compute_g(x);
    f_values = zeros(options.max_iterations, 1);
    f_values(1) = f;
    k = 1;
    
    % For SR1 TR1CG only
    if strcmp(method.name, 'TR1CG')
        B = eye(length(x));  % Initial Hessian approximation
        delta = method.delta0;
    end


    while norm(g, inf) > options.term_tol * max(norm(problem.compute_g(problem.x0), inf), 1) ...
          && k < options.max_iterations

        if strcmp(method.name, 'GradientDescent')
           d = -g;
           [x, f, g, success, alpha] = GDStep(x, problem, method, d);
           if ~success
                warning('%s (%s) terminated early: step condition failed.', ...
                       method.name, method.step_type);
                break;
            end

        elseif strcmp(method.name, 'TRNewtonCG')
            [x, f, g, delta] = TRCGStep(x, problem, method, options);
            method.delta0 = delta;

        elseif strcmp(method.name, 'TR1CG')
            [x, f, g, delta, B] = TR1CGStep(x, f, g, B, problem, delta, options);


        else
            error('Unknown optimization method.');
        end

        k = k + 1;
        f_values(k) = f;
    end

    f_values = f_values(1:k);
    fprintf('%s (%s) terminated after %d iterations. Final f(x)=%.6e\n', ...
            method.name, method.step_type, k, f);
end
