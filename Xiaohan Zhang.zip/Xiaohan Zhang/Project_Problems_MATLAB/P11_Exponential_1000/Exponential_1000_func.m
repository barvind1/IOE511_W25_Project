% Problem Number: 11
% Problem Name: Exponential_1000
% Problem Description: Exponential function. Dimension n = 1000
% function that computes the function value of the Exponential_1000 function
function [f] = Exponential_1000_func(x)
    % First term with x[1]
    term1 = (exp(x(1)) - 1)/(exp(x(1)) + 1);
    term2 = 0.1*exp(-x(1));
    
    % Sum of quartic terms (vectorized)
    term3 = sum((x(2:end) - 1).^4);
    
    % Combine all terms
    f = term1 + term2 + term3;
end