function [g] = Exponential_1000_grad(x)
    % Vectorized gradient computation
    g = zeros(1000, 1);
    
    % First component
    g(1) = (2*exp(x(1)))/(exp(x(1)) + 1)^2 - 0.1*exp(-x(1));
    
    % Components 2 through 1000 (vectorized)
    g(2:end) = 4*(x(2:end) - 1).^3;
end