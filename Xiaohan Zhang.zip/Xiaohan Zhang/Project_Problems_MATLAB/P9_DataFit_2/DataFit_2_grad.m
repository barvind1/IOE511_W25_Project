function [g] = DataFit_2_grad(x)
    % Data points
    y = [1.5; 2.25; 2.625];
    
    % Vectorized computation of gradient
    g = zeros(2, 1);
    g(1) = -2 * sum((1 - x(2).^(1:3)') .* (y - x(1)*(1 - x(2).^(1:3)'))); 
    g(2) = 2 * x(1) * sum((1:3)' .* x(2).^((1:3)'-1) .* (y - x(1)*(1 - x(2).^(1:3)'))); 
end