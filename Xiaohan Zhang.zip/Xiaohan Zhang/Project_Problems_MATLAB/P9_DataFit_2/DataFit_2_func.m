% Problem Number: 9
% Problem Name: DataFit_2
% Problem Description: Data fitting function. Dimension n = 2
% function that computes the function value of the DataFit_2 function
function [f] = DataFit_2_func(x)
    % Data points
    y = [1.5; 2.25; 2.625];
    
    % compute function value using vectorized form
    f = sum((y - x(1)*(1 - x(2).^(1:3)')).^2);
end