function [method, method_name] = Setmethods(method_id)
    % SETMETHOD 设置优化方法
    %
    % 输入:
    %   method_id - 方法ID (1: Newton, 2: NewtonW, 3: DFP)
    %
    % 输出:
    %   method - 方法函数句柄
    %   method_name - 方法名称
    
    switch method_id
        case 1
            method = @Newton_backtracking;
            method_name = 'Newton with Backtracking';
        case 2
            method = @NewtonW_wolfe;
            method_name = 'Newton with Wolfe';
        case 3
            method = @DFP_backtracking;
            method_name = 'DFP with Backtracking';
        otherwise
            error('Unknown method ID: %d', method_id);
    end
end