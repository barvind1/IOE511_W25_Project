function [x_new, alpha, eta_history]= Modified_Newton_with_Wolfe(x, problem, options)
% NewtonW_with_Wolfe_LS: Newton method with Wolfe line search
%
% Input:
% x - current point
% problem - f(x); gradient; hessian
% options - parameters: alpha, c1, c2, beta = 1e-6, eta_k = 0, max_ls_iter
%
% Output:
% x_new - new point after iteration
% alpha - step size of Wolfe search method
% eta_history - history of eta values used for Hessian modification
grad_f = problem.grad(x);
H = problem.hess(x); % original hessian
min_diag = min(diag(H));
if min_diag > 0
    eta_k = 0;
else
    eta_k = -min_diag + options.beta;
end

% Cholesky decomposition
success = false;
eta_history = []; % record eta_k of each iteration
for k = 0:100
    H_modified = H + eta_k * eye(size(H));
    [L, flag] = chol(H_modified, 'lower');
    if flag == 0
        success = true;
        break;
    else
        % update eta_k
        eta_k = max(2*eta_k, options.beta);
        eta_history = [eta_history, eta_k];
    end
end

if ~success
    error('Hessian cannot be revised.');
end

% H_modified * d = -grad
d = -L' \ (L \ grad);

% Wolfe Line Search: Check Armijo-Wolfe condition
f_val = problem.f(x);
alpha = options.alpha;
max_ls_iters = options.max_ls_iters;

for ls_iter = 1:max_ls_iters
    x_candidate = x + alpha*d;
    f_candidate = problem.f(x_candidate);
    grad_candidate = problem.grad(x_candidate);
    
    % Armijo condition
    armijo = f_candidate <= f_val + options.c1 * alpha * (grad' * d);
    
    % Wolfe curvature
    curvature = grad_candidate' * d >= options.c2 * grad' * d;
    
    if armijo && curvature 
        break;
    else
        alpha = alpha * options.tau;
    end
    
    fprintf('Newton Wolfe Iteration: %d, Alpha: %f, f(x): %e\n', ls_iter, alpha, f_val);
    
    if alpha < 1e-10
        fprintf('Warning: The stepsize is too small, line search terminates.\n');
        break;
    end
end

% Update
x_new = x + alpha*d;
end