function [options] = Setoptions(method_id)
    % SETOPTIONS 设置算法参数
    %
    % 输入:
    %   method_id - 方法ID
    %
    % 输出:
    %   options - 包含算法参数的结构体
    
    % 通用参数设置
    options = struct();
    options.max_iter = 1000;    % 最大迭代次数
    options.tol = 1e-6;         % 收敛容差
    
    % 根据方法ID设置特定参数
    switch method_id
        case 1  % Newton with Backtracking
            options.alpha = 0.3;  % 回溯线搜索参数
            options.beta = 0.8;   % 回溯线搜索参数
            
        case 2  % NewtonW with Wolfe
            options.c1 = 1e-4;    % Wolfe条件参数
            options.c2 = 0.9;     % Wolfe条件参数
            
        case 3  % DFP with Backtracking
            options.alpha = 0.3;  % 回溯线搜索参数
            options.beta = 0.8;   % 回溯线搜索参数
    end
end