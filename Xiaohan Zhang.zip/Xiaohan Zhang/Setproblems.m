function [problem_info] = Setproblems(problem_id)
  % SETPROBLEMS 设置优化问题
    %
    % 输入:
    %   problem_id - 问题ID (1-12)
    %
    % 输出:
    %   problem_info - 包含问题信息的结构体
    %     .id        - 问题标识符
    %     .name      - 问题名称
    %     .func      - 目标函数句柄（如果提供）
    %     .grad      - 梯度函数句柄（如果提供）
    %     .hess      - Hessian函数句柄（如果提供）
    %     .x0        - 初始点
    %     .dimension - 问题维度
    %     .has_func  - 是否提供了函数
    %     .has_grad  - 是否提供了梯度
    %     .has_hess  - 是否提供了Hessian
    
    problem_info = struct();
    
    switch problem_id
        case 1
            % P1: 二次函数 n=10, κ=10
            problem_info.id = 'P1_quad_10_10';
            problem_info.name = 'Quadratic Function n=10, κ=10';
            problem_info.dimension = 10;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;
            
            % 设置随机数种子以确保可重现性
            rng(0);
            problem_info.x0 = 20*rand(10, 1) - 10;

            % 使用已有的函数
            problem_info.func = @quad_10_10_func;
            problem_info.grad = @quad_10_10_grad;
            problem_info.hess = @quad_10_10_Hess;
            
        case 2
            % P2: 二次函数 n=10, κ=1000
            problem_info.id = 'P2_quad_10_1000';
            problem_info.name = 'Quadratic Function n=10, κ=1000';
            problem_info.dimension = 10;
            problem_info.has_func = true;
            problem_info.has_grad = true; 
            problem_info.has_hess = true;
            
            rng(0);
            problem_info.x0 = 20*rand(10, 1) - 10;
            problem_info.func = @quad_10_1000_func;

            problem_info.grad =  @quad_10_1000_grad;
            problem_info.hess =  @quad_10_1000_Hess;


        case 3
            % P3: 二次函数 n=1000, κ=10
            problem_info.id = 'P3_quad_1000_10';
            problem_info.name = 'Quadratic Function n=1000, κ=10';
            problem_info.dimension = 1000;
            problem_info.has_func = true;
            problem_info.has_grad = true; 
            problem_info.has_hess = true;
            
            rng(0);
            problem_info.x0 = 20*rand(1000, 1) - 10;
            problem_info.func = @quad_1000_10_func;

            problem_info.grad =  @quad_1000_10_grad;
            problem_info.hess =  @quad_1000_10_Hess;

         case 4
            % P4: 二次函数 n=1000, κ=1000
            problem_info.id = 'P4_quad_1000_1000';
            problem_info.name = 'Quadratic Function n=1000, κ=1000';
            problem_info.dimension = 1000;
            problem_info.has_func = true;
            problem_info.has_grad = true; 
            problem_info.has_hess = true;
            
            rng(0);
            problem_info.x0 = 20*rand(1000, 1) - 10;
            problem_info.func = @quad_1000_1000_func;

            problem_info.grad =  @quad_1000_1000_grad;
            problem_info.hess =  @quad_1000_1000_Hess;
        
        case 5
            % P5: Quartic Function with σ=10^-4
            problem_info.id = 'P5_quartic_1';
            problem_info.name = 'Quartic Function with σ=10^-4';
            problem_info.dimension = 4;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;
            
            problem_info.x0 = [cos(70); sin(70); cos(70); sin(70)];
            problem_info.func = @quartic_1_func;
            problem_info.grad = @quartic_1_grad;
            problem_info.hess = @quartic_1_Hess;


        case 6
            % P5: Quartic Function with σ=10^-4
            problem_info.id = 'P6_quartic_2';
            problem_info.name = 'Quartic Function with σ=10^4';
            problem_info.dimension = 4;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;
            
            problem_info.x0 = [cos(70); sin(70); cos(70); sin(70)];
            problem_info.func = @quartic_2_func;
            problem_info.grad = @quartic_2_grad;
            problem_info.hess = @quartic_2_Hess;
            
        case 7
            % P7: Rosenbrock 2D
            problem_info.id = 'P7_Rosenbrock_2';
            problem_info.name = 'Rosenbrock Function n=2';
            problem_info.dimension = 2;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;
            problem_info.x0 = [-1.2; 1.0];
            problem_info.func = @Rosenbrock_2_func;
            problem_info.grad = @Rosenbrock_2_grad;
            problem_info.hess = @Rosenbrock_2_Hess;

        case 8
            % P8: Rosenbrock 100D
            problem_info.id = 'P8_Rosenbrock_100';
            problem_info.name = 'Rosenbrock Function n=100';
            problem_info.dimension = 100;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = false;
            x0 = ones(100, 1);  % 先全部初始化为1
            x0(1) = -1.2;       % 然后设置第一个元素为-1.2
            problem_info.x0 = x0;
            problem_info.func = @rosenbrock_100_func;
            problem_info.grad = @rosenbrock_100_grad;
            problem_info.hess = @(x) numerical_hessian(problem_info.grad, x);

        case 9
           % P9: DataFit_2
            problem_info.id = 'P9_DataFit_2';
            problem_info.name = 'Data Fitting Function n=2';
            problem_info.dimension = 2;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true; 
            problem_info.x0 = [1; 1];
            problem_info.func = @DataFit_2_func;
            problem_info.grad = @DataFit_2_grad;
            problem_info.hess = @DataFit_2_Hess;

        case 10
           % P10: Exponential_10
            problem_info.id = 'P10_Exponential_10';
            problem_info.name = 'Exponential Function n=10';
            problem_info.dimension = 10;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;  
            problem_info.x0 = [1; zeros(9, 1)];
            problem_info.func = @Exponential_10_func;
            problem_info.grad = @Exponential_10_grad;
            problem_info.hess = @Exponential_10_Hess;

       case 11
          % P11: Exponential_100
            problem_info.id = 'P11_Exponential_100';
            problem_info.name = 'Exponential Function n=100';
            problem_info.dimension = 100;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;  
            problem_info.x0 = [1; zeros(99, 1)];
            problem_info.func = @Exponential_100_func;
            problem_info.grad = @Exponential_100_grad;
            problem_info.hess = @Exponential_100_Hess;

       case 12

          % P12: Genhumps_5
            problem_info.id = 'P12_Genhumps_5';
            problem_info.name = 'Generalized Humps Function n=5';
            problem_info.dimension = 5;
            problem_info.has_func = true;
            problem_info.has_grad = true;
            problem_info.has_hess = true;
            problem_info.x0 = [-506.2; 506.2; 506.2; 506.2; 506.2];
            problem_info.func = @genhumps_5_func;
            problem_info.grad = @genhumps_5_grad;
            problem_info.hess = @genhumps_5_Hess;
            
        otherwise
            error('Unknown problem ID: %d', problem_id);
    end
end

