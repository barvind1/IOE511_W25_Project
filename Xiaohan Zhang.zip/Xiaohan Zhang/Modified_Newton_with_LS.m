function [x_new, alpha, eta_history] = Modified_Newton_with_LS(x, problem, options)
% ModifiedNewtonStep_Backtracking: Modified Newton method and backtracking search method
%
% Input:
%   x       - current point
%   problem - f(x); gradient; hessian
%   options - parameters: alpha , tau , c1, beta = 1e-6, eta_k = 0
%
% Output:
%   x_new   - new point after iteration
%   alpha   - step size of backtracking search method

grad_f = problem.grad(x);
H = problem.hess(x); % original hessian

min_diag = min(diag(H));

if min_diag >0
    eta_k = 0;
else
    eta_k = -min_diag +options.beta;
end

% Cholesky decomposition
success = false;
eta_history = []; %record eta_k of each iteration
for k = 0:100 
    H_modified = H + eta_k * eye(size(H));
    [L, flag] = chol(H_modified, 'lower');

    if flag == 0
        success = true;
        break;
    else
        % update eta_k
        eta_k = max(2*eta_k,options.beta);
        eta_history = [eta_history, eta_k];
    end
end

if ~success
    error('Hessian cannot be modified!');
end


% Modified Newton direction: H_modified * d = -grad
d = -L' \ (L \ grad_f); 

% backtracking search method：check Armijo condition
alpha = options.alpha;
f_x = problem.f(x);
iter = 0;
while problem.f(x + alpha*d) > f_x + options.c1*alpha*(grad_f' * d)
    alpha = options.tau * alpha;
    iter = iter + 1;  % add the interation times
        
    % print the iteration and result
    fprintf('Modified Newton Iteration: %d, Alpha: %f, f(x): %e\n', iter, alpha, problem.f(x));
end

x_new = x + alpha*d;
end
