function [x_new, alpha, iter] = DFP_with_backtracking_LS(x, problem, options)
% DFP_with_backtracking: DFP quasi-Newton method with backtracking line search
%
% Input:
% x - current point
% problem - f(x), gradient
% options - parameters: alpha, tau, c1, B (inverse Hessian approximation)
%
% Output:
% x_new - new point after iteration
% alpha - step size of backtracking search method
% iter - number of backtracking iterations

grad_f = problem.grad(x);

% Get the inverse Hessian approximation
if isfield(options, 'B')
    B = options.B;
else
    % Initialize with identity matrix if not provided
    B = eye(length(x));
end

% Compute search direction
d = -B * grad_f;

% Check if d is a descent direction
if grad_f' * d > 0
    % If not a descent direction, use negative gradient
    d = -grad_f;
    fprintf('Warning: DFP direction not a descent direction, using gradient\n');
end

% Backtracking line search: check Armijo condition
alpha = options.alpha;
f_x = problem.f(x);
iter = 0;

while problem.f(x + alpha*d) > f_x + options.c1*alpha*(grad_f' * d)
    alpha = options.tau * alpha;
    iter = iter + 1;
    % Print iteration and result
    fprintf('DFP Backtracking Iteration: %d, Alpha: %f, f(x): %e\n', iter, alpha, problem.f(x));
    
    % Break if step size becomes too small
    if alpha < 1e-10
        fprintf('Warning: Step size too small, terminating backtracking\n');
        break;
    end
end

% Update point
x_new = x + alpha * d;

% Compute y_k = grad_f(x_new) - grad_f(x)
grad_f_new = problem.grad(x_new);
y = grad_f_new - grad_f;

% Compute s_k = x_new - x
s = alpha * d;

% Update inverse Hessian approximation using DFP formula
% Only update if s'y is sufficiently positive
if s' * y > 1e-10
    % DFP update: B_{k+1} = B_k - (B_k*y*y'*B_k)/(y'*B_k*y) + (s*s')/(s'*y)
    By = B * y;
    B = B - (By * By') / (y' * By) + (s * s') / (y' * s);
else
    fprintf('Warning: Skipping DFP update, s''y too small\n');
end

% Store updated B in options for next iteration
options.B = B;
end