function [x_new, f_new, g_new, success, alpha] = GDStep(x, problem, method, d)
    if nargin < 4
        d = -problem.compute_g(x);
    end

    g = problem.compute_g(x);
    f = problem.compute_f(x);

    % Weak Wolfe Line Search from the Armijo PDF in Project Folder Canvas
    if strcmp(method.step_type, 'GradientDescentW')
        % Defaults
        c1 = method.c1;
        c2 = method.c2;
        alpha = method.alpha;
        alpha_low = method.alpha_low;
        alpha_high = method.alpha_high;
        c = method.c;

        while true
            x_trial = x + alpha * d;
            f_trial = problem.compute_f(x_trial);

            % Check Armijo condition
            if f_trial > f + c1 * alpha * g' * d
                alpha_high = alpha;
            else
                % Check curvature condition
                g_trial = problem.compute_g(x_trial);
                if g_trial' * d >= c2 * g' * d
                    break;  % Both conditions satisfied
                end
                alpha_low = alpha;
            end

            % Update alpha
            alpha = c * alpha_low + (1 - c) * alpha_high;
        end

    % Backtracking Line Search
    elseif strcmp(method.step_type, 'GradientDescent')
        alpha = method.alpha_bar;
        while problem.compute_f(x + alpha * d) > f + method.c1 * alpha * g' * d
            alpha = method.tau * alpha;
        end

    % Constant Step Size
    elseif strcmp(method.step_type, 'Constant')
        alpha = method.constant_step_size;

    else
        error('Invalid step_type.');
    end

    % Final update
    x_new = x + alpha * d;
    f_new = problem.compute_f(x_new);
    g_new = problem.compute_g(x_new);
    success = 1;
end
