function problem = setProblem(params)
    if ~isfield(params, 'name')
        error('Field \"name\" is required in params.');
    end

    name = params.name;
    problem.name = name;

    % === Starting point from Project_Problems.pdf ===
    problem.x0 = getStartingPoint(name);

    % === Function ===
    if exist([name '_func.m'], 'file')
        problem.compute_f = @(x) feval([name '_func'], x);
    else
        error('Missing function file: %s_func.m', name);
    end

    % === Gradient ===
    if exist([name '_grad.m'], 'file')
        problem.compute_g = @(x) feval([name '_grad'], x);
    else
        error('Missing gradient file: %s_grad.m', name);
    end

    % === Hessian (optional) ===
    if exist([name '_Hess.m'], 'file')
        problem.compute_H = @(x) feval([name '_Hess'], x);
    else
        problem.compute_H = @(x) eye(length(problem.x0));  % fallback allowed
    end

    problem.f_star = NaN;
end

function x0 = getStartingPoint(name)
    switch name
        case {'quad_10_10', 'quad_10_1000'}
            rng(0); x0 = 20 * rand(10, 1) - 10;

        case {'quad_1000_10', 'quad_1000_1000'}
            rng(0); x0 = 20 * rand(1000, 1) - 10;

        case {'quartic_1', 'quartic_2'}
            x0 = [cosd(70); sind(70); cosd(70); sind(70)];

        case 'genhumps_5'
            x0 = [-506.2; 506.2; 506.2; 506.2; 506.2];

        case 'Rosenbrock_2'
            x0 = [-1.2; 1];

        case 'Rosenbrock_100'
            x0 = [-1.2; ones(99,1)];

        case 'Datafit_2'
            x0 = [1; 1];

        case 'Exponential_10'
            x0 = [1; zeros(9,1)];

        case 'Exponential_1000'
            x0 = [1; zeros(999,1)];

        otherwise
            error('Unknown problem name for x0: %s', name);
    end
end
