function f = Exponential_1000_func(x)
% Problem 11 - Exponential_1000

f = (exp(x(1)) - 1)/(exp(x(1)) + 1) + 0.1 * exp(-x(1)) + sum((x(2:end) - 1).^4);
end
