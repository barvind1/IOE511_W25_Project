function g = Exponential_1000_grad(x)
% Gradient of Exponential_1000 (same for Exponential_1000)
n = length(x);
g = zeros(n,1);

% First component
g(1) = 2 * exp(x(1)) / (exp(x(1)) + 1)^2 - 0.1 * exp(-x(1));

% Remaining components
g(2:end) = 4 * (x(2:end) - 1).^3;
end