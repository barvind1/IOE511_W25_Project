function g = quartic_1_grad(x)
% IOE 511/MATH 562, University of Michigan
% Problem Number: 5
% Problem Name: quartic_1

Q = [5 1 0 0.5;
     1 4 0.5 0;
     0 0.5 3 0;
     0.5 0 0 2];

sigma = 1e-4;

qx = Q * x;
g = x + sigma * (x' * qx) * qx;
end
