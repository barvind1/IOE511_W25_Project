function g = Rosenbrock_2_grad(x)
% Gradient of Rosenbrock function (n=2)
g = [
    -2 * (1 - x(1)) - 400 * x(1) * (x(2) - x(1)^2);
    200 * (x(2) - x(1)^2)
];
end
