function f = Rosenbrock_2_func(x)
% Rosenbrock function for n = 2
f = (1 - x(1))^2 + 100 * (x(2) - x(1)^2)^2;
end
