function H = Rosenbrock_100_Hess(x)
% Hessian of Rosenbrock function for n = 100
n = length(x);
H = zeros(n, n);

for i = 1:n-1
    H(i,i) = H(i,i) + 1200*x(i)^2 - 400*x(i+1) + 2;
    H(i,i+1) = H(i,i+1) - 400*x(i);
    H(i+1,i) = H(i+1,i) - 400*x(i);
    H(i+1,i+1) = H(i+1,i+1) + 200;
end
end
