function H = Exponential_10_Hess(x)
% Hessian of Exponential_10 (same for Exponential_1000)
n = length(x);
H = zeros(n, n);

% First diagonal element
H(1,1) = (2 * exp(x(1)) * (1 - exp(x(1)))) / (exp(x(1)) + 1)^3 + 0.1 * exp(-x(1));

% Remaining diagonal elements
H(2:end, 2:end) = diag(12 * (x(2:end) - 1).^2);
end
