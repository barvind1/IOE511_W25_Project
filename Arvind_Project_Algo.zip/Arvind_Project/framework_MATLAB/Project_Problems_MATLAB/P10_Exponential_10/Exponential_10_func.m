function f = Exponential_10_func(x)
% Problem 10 - Exponential_10 (also used for Exponential_1000 by adjusting x)

f = (exp(x(1)) - 1)/(exp(x(1)) + 1) + 0.1 * exp(-x(1)) + sum((x(2:end) - 1).^4);
end
