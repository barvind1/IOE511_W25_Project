% IOE 511/MATH 562, University of Michigan
% Code written by: Albert S. Berahas

% Problem Number: 3
% Problem Name: quad_1000_10
% Problem Description: A randomly generated convex quadratic function; the 
%                      random seed is set so that the results are 
%                      reproducable. Dimension n = 1000; Condition number
%                      kappa = 10

% function that computes the function value of the quad_10_10 function
function [f] = quad_1000_10_func(x)

%Making Q adn q generated fisrt persistent, else it takes lot of time to
%generate them everytime
persistent Q q


if isempty(Q) %Check to ensure Q and q are not regenerated every time
% Set random number generator seeds
rng(0);

% Generate random data
q = randn(1000,1);
% MATLAB sprandsym function. Inputs: n, density, reciprocal of the 
% condition number, and kind 
% (see https://www.mathworks.com/help/matlab/ref/sprandsym.html)
Q = sprandsym(1000,0.5,0.1,1);

end

% compute function value
f = 1/2*x'*Q*x + q'*x;
