function options = setOptions()
    options.term_tol = 1e-6;
    options.max_iterations = 1000;
    options.c1_ls = 1e-4;
    options.c2_ls = 0.9;
    options.c1_tr = 0.1;
    options.c2_tr = 0.6;
    options.term_tol_CG = 1e-6;
    options.max_iterations_CG = 200;
    options.beta = 1e-6;  % for modified Newton
end
