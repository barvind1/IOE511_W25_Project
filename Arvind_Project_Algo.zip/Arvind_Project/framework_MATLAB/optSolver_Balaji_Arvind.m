function [x, f, f_values] = optSolver_Balaji_Arvind(problem, method, options)
    x = problem.x0;
    f = problem.compute_f(x);
    g = problem.compute_g(x);
    f_values = zeros(options.max_iterations, 1);
    f_values(1) = f;
    k = 1;


    
    while norm(g, inf) > options.term_tol * max(norm(problem.compute_g(problem.x0), inf), 1) ...
          && k < options.max_iterations

        if strcmp(method.name, 'GradientDescent')
            d = -g;
            [x, f, g, ~, alpha] = GDStep(x, problem, method, d);

        elseif strcmp(method.name, 'TRNewtonCG')
    [x, f, g, delta] = TRCGStep(x, problem, method, options);  % Capture new delta
    method.delta0 = delta;  % Update for next iteration
        else
            error('Unknown optimization method.');
        end

        k = k + 1;
        f_values(k) = f;
    end

    f_values = f_values(1:k);
    fprintf('%s (%s) terminated after %d iterations. Final f(x)=%.6e\n', ...
    method.name, method.step_type, k, f);

end