function [x_new, f_new, g_new, delta] = TRCGStep(x, problem, method, options)

    % Main trust-region Newton-CG step

    % Retrieve current values
    delta = method.delta0;
    c1 = options.c1_tr;
    c2 = options.c2_tr;

    f = problem.compute_f(x);
    g = problem.compute_g(x);
    B = problem.compute_H(x);

    % Step [2] - Solve TR subproblem approximately
    d = solveTRSubproblem_CG(g, B, delta, options.term_tol_CG, options.max_iterations_CG);

    % Step [3] - Evaluate rho
    f_trial = problem.compute_f(x + d);
    actual_reduction = f - f_trial;
    predicted_reduction = -g' * d - 0.5 * d' * B * d;
    rho = actual_reduction / predicted_reduction;

    %fprintf('[TR] rho = %.4f | delta = %.4f | actual = %.4e | predicted = %.4e\n', ...
    %rho, delta, actual_reduction, predicted_reduction);

    % Step [4–9] - Trust region logic from slides
    if rho > c1
        x_new = x + d;   % Accept
        if rho > c2
            delta = 2 * delta;
        end
    else
        x_new = x;              % Reject
        delta = 0.5 * delta;
    end

    % Return values
    f_new = problem.compute_f(x_new);
    g_new = problem.compute_g(x_new);
    %success = 1;
    %alpha = 1;  % placeholder to match interface
end

function d = solveTRSubproblem_CG(g, B, delta, tol_CG, max_iter_CG)
    % Conjugate Gradient subproblem solver for trust-region

    z = zeros(size(g));
    r = g;
    p = -r;

    if norm(r) < tol_CG
        d = z;
        return;
    end

    for j = 1:max_iter_CG
        Bp = B * p;
        pBp = p' * Bp;

        %Debug print statement
        %fprintf('[TRCG] Iter %d | ‖r‖=%.3e | ‖z‖=%.3e | pBp=%.3e\n', ...
                %j, norm(r), norm(z), pBp);

        if pBp <= 0
            tau = findTau(z, p, delta);
            d = z + tau * p;
            return;
        end

        alpha_j = (r' * r) / pBp;
        z_new = z + alpha_j * p;

        if norm(z_new) >= delta
            tau = findTau(z, p, delta);
            d = z + tau * p;
            return;
        end

        r_new = r + alpha_j * Bp;

        if norm(r_new) <= tol_CG
            d = z_new;
            return;
        end

        beta = (r_new' * r_new) / (r' * r);
        p = -r_new + beta * p;
        r = r_new;
        z = z_new;
    end

    d = z;
end

function tau = findTau(z, p, delta)
    % Find tau such that ||z + tau*p|| = delta
    a = norm(p)^2;
    b = 2 * z' * p;
    c = norm(z)^2 - delta^2;
    discriminant = b^2 - 4 * a * c;
    tau = (-b + sqrt(discriminant)) / (2 * a);  % larger root
end