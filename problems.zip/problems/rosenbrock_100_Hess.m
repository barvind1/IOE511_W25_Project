% Problem Number: 8
% Problem Name: Rosenbrock_100
% Problem Description: Rosenbrock function. Dimension n = 100
% Function that computes the Hessian of the Rosenbrock_100 function
function [H] = rosenbrock_100_Hess(x)
    % Hessian matrix of the Rosenbrock function
    n = 100;
    
    % Use sparse matrix for memory efficiency
    H = spalloc(n, n, 3*n); % Preallocate space, at most 3 non-zero elements per row
    
    % Compute the Hessian elements for the first variable
    H(1,1) = 2 + 800*x(1)^2 - 400*x(2) + 400;
    H(1,2) = -400*x(1);
    H(2,1) = -400*x(1);
    
    % Compute the Hessian elements for the intermediate variables
    for i = 2:n-1
        % Diagonal element
        H(i,i) = 202 + 800*x(i)^2 - 400*x(i+1);
        
        % Cross term with the previous variable
        H(i,i-1) = -400*x(i-1);
        H(i-1,i) = -400*x(i-1);
        
        % Cross term with the next variable
        H(i,i+1) = -400*x(i);
        H(i+1,i) = -400*x(i);
    end
    
    % Compute the Hessian elements for the last variable
    H(n,n) = 200;
    H(n,n-1) = -400*x(n-1);
    H(n-1,n) = -400*x(n-1);
end

