function [g] = Exponential_100_grad(x)
    % Vectorized gradient computation
    g = zeros(100, 1);
    
    % First component
    g(1) = (2*exp(x(1)))/(exp(x(1)) + 1)^2 - 0.1*exp(-x(1));
    
    % Components 2 through 100 (vectorized)
    g(2:end) = 4*(x(2:end) - 1).^3;
end