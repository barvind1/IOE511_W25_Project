% Problem Number: 7
% Problem Name: Rosenbrock_2
% Problem Description: Rosenbrock function. Dimension n = 2
% function that computes the gradient of the Rosenbrock_2 function
function [g] = Rosenbrock_2_grad(x)
    % compute gradient
    g = [-2*(1-x(1)) - 400*x(1)*(x(2)-x(1)^2);
         200*(x(2)-x(1)^2)];
end