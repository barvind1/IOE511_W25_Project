% Problem Number: 8
% Problem Name: Rosenbrock_100
% Problem Description: Rosenbrock function. Dimension n = 100
% function that computes the gradient of the Rosenbrock_100 function
function [g] = rosenbrock_100_grad(x)
    % compute gradient
    n = 100;
    g = zeros(n, 1);
    
    % First component
    g(1) = -2*(1-x(1)) - 400*x(1)*(x(2)-x(1)^2);
    
    % Middle components
    for i = 2:n-1
        g(i) = 200*(x(i)-x(i-1)^2) - 2*(1-x(i)) - 400*x(i)*(x(i+1)-x(i)^2);
    end
    
    % Last component
    g(n) = 200*(x(n)-x(n-1)^2);
end