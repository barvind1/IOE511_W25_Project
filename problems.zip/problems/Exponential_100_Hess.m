function [H] = Exponential_100_Hess(x)
    % Create diagonal matrix with Hessian elements
    diag_values = zeros(100, 1);
    
    % First diagonal element
    diag_values(1) = (2*exp(x(1))*(1 - exp(x(1))))/(exp(x(1)) + 1)^3 + 0.1*exp(-x(1));
    
    % Remaining diagonal elements
    diag_values(2:end) = 12*(x(2:end) - 1).^2;
    
    % Create diagonal Hessian
    H = diag(diag_values);
end