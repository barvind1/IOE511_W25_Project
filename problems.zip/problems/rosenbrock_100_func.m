% Problem Number: 8
% Problem Name: Rosenbrock_100
% Problem Description: Rosenbrock function. Dimension n = 100
% function that computes the function value of the Rosenbrock_100 function
function [f] = rosenbrock_100_func(x)
    % compute function value
    f = 0;
    for i = 1:99
        f = f + (1 - x(i))^2 + 100*(x(i+1) - x(i)^2)^2;
    end
end