% IOE 511/MATH 562, University of Michigan
% Code written by: Albert S. Berahas

% Problem Number: 3
% Problem Name: quad_1000_10
% Problem Description: A randomly generated convex quadratic function; the 
%                      random seed is set so that the results are 
%                      reproducable. Dimension n = 1000; Condition number
%                      kappa = 10

% function that computes the function value of the quad_10_10 function

function [f] = quad_1000_10_func(x)
    persistent Q q initialized;
    
    % Initialize only on first call
    if isempty(initialized)
        rng(0); % Ensure reproducibility
        q = randn(1000, 1);
        % Use sprandsym to generate a sparse symmetric matrix
        Q = sprandsym(1000, 0.5, 0.1, 1);
        initialized = true;
    end
    
    % Compute function value
    f = 0.5 * x' * Q * x + q' * x;
end
