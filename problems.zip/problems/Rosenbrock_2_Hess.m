% Problem Number: 7
% Problem Name: Rosenbrock_2
% Problem Description: Rosenbrock function. Dimension n = 2
% function that computes the Hessian of the Rosenbrock_2 function
function [H] = Rosenbrock_2_Hess(x)
    % compute Hessian matrix
    H = [2 - 400*(x(2)-x(1)^2) + 800*x(1)^2, -400*x(1);
         -400*x(1), 200];
end