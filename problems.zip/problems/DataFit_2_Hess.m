function [H] = DataFit_2_Hess(x)
    % Data points
    y = [1.5; 2.25; 2.625];
    
    % Compute Hessian components
    H = zeros(2, 2);
    
    % (1,1) element
    H(1,1) = 2 * sum((1 - x(2).^((1:3)')).^2);
    
    % (1,2) and (2,1) elements (symmetric)
    H(1,2) = 2 * sum((1:3)' .* x(2).^((0:2)') .* (y - 2*x(1)*(1 - x(2).^((1:3)'))));
    H(2,1) = H(1,2);
    
    % (2,2) element
    H(2,2) = 2 * x(1)^2 * sum((1:3)'.^2 .* x(2).^(2*(1:3)' - 2)) + ...
             2 * x(1) * sum((1:3)'.*(0:2)' .* x(2).^((-1:1)') .* (y - x(1)*(1 - x(2).^((1:3)'))));
end