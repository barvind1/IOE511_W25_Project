

% Problem Number: 1
% Problem Name: quad_1000_10
% Problem Description: A randomly generated convex quadratic function; the 
%                      random seed is set so that the results are 
%                      reproducable. Dimension n = 1000; Condition number
%                      kappa = 10

% function that computes the Hessian of the quad_10_10 function
function [H] = quad_1000_10_Hess(x)
    persistent Q initialized;
    
    % Initialize only on first call
    if isempty(initialized)
        rng(0); % Ensure reproducibility
        % Use sprandsym to generate a sparse symmetric matrix
        Q = sprandsym(1000, 0.5, 0.1, 1);
        initialized = true;
    end
    
    % Return Hessian
    H = Q;
end
