function [x_final, f_final, iteration_count, f_history, grad_norm_history] = Modified_Newton_with_LS(problem_info, options)
% Modified_Newton_with_LS: Modified Newton Method with Backtracking Line Search
%
% Inputs:
%   problem_info - Struct containing problem information
%     .func      - Objective function handle
%     .grad      - Gradient function handle
%     .hess      - Hessian function handle
%     .x0        - Initial point
%   options - Optimization options
%     .alpha     - Initial step size
%     .tau       - Backtracking factor
%     .c1        - Armijo condition parameter
%     .beta      - Minimum Hessian shift
%     .max_iter  - Maximum number of iterations
%     .tol       - Convergence tolerance
%
% Outputs:
%   x_final           - Final solution
%   f_final           - Final function value
%   iteration_count   - Number of iterations
%   f_history         - History of function values
%   grad_norm_history - History of gradient norms

% Extract initial point and problem data
x = problem_info.x0;
func = problem_info.func;
grad = problem_info.grad;
hess = problem_info.hess;

% Use default options if not provided
if nargin < 2 || isempty(options)
    options = struct();
end
if ~isfield(options, 'alpha')
    options.alpha = 1.0;
end
if ~isfield(options, 'tau')
    options.tau = 0.5;
end
if ~isfield(options, 'c1')
    options.c1 = 1e-4;
end
if ~isfield(options, 'beta')
    options.beta = 1e-6;
end
if ~isfield(options, 'max_iter')
    options.max_iter = 1000;
end
if ~isfield(options, 'tol')
    options.tol = 1e-6;
end

% Compute initial function value and gradient
f = func(x);
g = grad(x);
grad_norm = norm(g);

% Initialize history records
max_iter = options.max_iter;
f_history = zeros(max_iter+1, 1);
grad_norm_history = zeros(max_iter+1, 1);

% Record initial values
f_history(1) = f;
grad_norm_history(1) = grad_norm;

% Main iteration loop
iteration_count = 0;
all_eta_history = []; % Store eta history of all iterations

while (iteration_count < max_iter) && (grad_norm > options.tol)
    % Compute gradient and Hessian
    g = grad(x);
    H = hess(x);
    
    % Determine minimum diagonal value, compute eta_k
    min_diag = min(diag(H));
    if min_diag > 0
        eta_k = 0;
    else
        eta_k = -min_diag + options.beta;
    end
    
    % Cholesky decomposition
    success = false;
    eta_history = [];  % Record eta_k changes for current iteration
    
    for k = 0:100
        H_modified = H + eta_k * eye(size(H));
        [L, flag] = chol(H_modified, 'lower');
        
        if flag == 0
            success = true;
            break;
        else
            % Update eta_k
            eta_k = max(2*eta_k, options.beta);
            eta_history = [eta_history, eta_k];
        end
    end
    
    if ~success
        error('Hessian could not be modified!');
    end
    
    % Record eta history for this iteration
    all_eta_history = [all_eta_history; eta_history];
    
    % Compute modified Newton direction: H_modified * d = -grad
    d = -L' \ (L \ g);
    
    % Backtracking line search: check Armijo condition
    alpha = options.alpha;
    f_x = f;
    ls_iter = 0;
    
    while func(x + alpha*d) > f_x + options.c1*alpha*(g' * d)
        alpha = options.tau * alpha;
        ls_iter = ls_iter + 1;
        
        % Print iteration progress
        fprintf('Modified Newton LS iteration: %d, Alpha: %f, f(x): %e\n', ls_iter, alpha, func(x));
        
        % If step size is too small, exit
        if alpha < 1e-10
            fprintf('Warning: Step size too small, terminating line search\n');
            break;
        end
    end
    
    % Update point
    x_new = x + alpha * d;
    
    % Update variables
    x = x_new;
    f = func(x);
    g = grad(x);
    grad_norm = norm(g);
    
    % Update iteration count
    iteration_count = iteration_count + 1;
    
    % Record history
    f_history(iteration_count+1) = f;
    grad_norm_history(iteration_count+1) = grad_norm;
    
    % Optional: print progress
    if mod(iteration_count, 10) == 0
        fprintf('Iteration %d: f(x) = %.6e, ||g|| = %.6e\n', iteration_count, f, grad_norm);
    end
end

% Trim history arrays
f_history = f_history(1:iteration_count+1);
grad_norm_history = grad_norm_history(1:iteration_count+1);

% Set final results
x_final = x;
f_final = f;

% Print final results
fprintf('Modified Newton with LS completed: Iterations = %d, Function value = %.6e, Gradient norm = %.6e\n', ...
    iteration_count, f_final, grad_norm);

end
